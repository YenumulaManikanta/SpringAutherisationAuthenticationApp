package com.pawana.currency.entity;

public class CurrencyCalculation {
   
	private String source;
	private String destination;
	private String amountCalculation;
	
	
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getAmountCalculation() {
		return amountCalculation;
	}
	public void setAmountCalculation(String amountCalculation) {
		this.amountCalculation = amountCalculation;
	}
	
	
}
