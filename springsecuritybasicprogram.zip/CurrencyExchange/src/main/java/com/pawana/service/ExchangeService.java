package com.pawana.service;

import org.springframework.stereotype.Service;

import com.pawana.entity.Exchange;
@Service
public interface ExchangeService {
	public Exchange addorUpdateExchange(Exchange exchange);
	public Exchange getExchange(String source,String destination);

}
