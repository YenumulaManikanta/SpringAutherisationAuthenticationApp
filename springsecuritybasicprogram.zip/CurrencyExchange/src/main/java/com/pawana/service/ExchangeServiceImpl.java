package com.pawana.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pawana.entity.Exchange;
import com.pawana.repository.Repository;
@Service
public class ExchangeServiceImpl implements ExchangeService {
	@Autowired
	private Repository repository;

	@Override
	public Exchange addorUpdateExchange(Exchange exchange) {
		return repository.save(exchange);
	}

	@Override
	public Exchange getExchange(String source, String destination) {
		return repository.findBySourceAndDestination(source,destination);
	}

}
