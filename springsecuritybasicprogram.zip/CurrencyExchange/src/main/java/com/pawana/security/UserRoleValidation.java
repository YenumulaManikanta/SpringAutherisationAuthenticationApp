package com.pawana.security;

import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

@Component
public class UserRoleValidation {
	
	public boolean isAdmin(HttpHeaders header) {
	
	List<String> userInfo =	header.get("user") ;
	String user = userInfo.get(0);
	if(user.equals("user")) {
		return true;
	}
	
	return false;
	}
	
	public boolean isAdminOrUser(HttpHeaders header) {
		
		List<String> userInfo =	header.get("user") ;
		String user = userInfo.get(0);
		if(user.equals("user") || user.equals("vasu")) {
			return true;
		}
		
		return false;
		}

}
