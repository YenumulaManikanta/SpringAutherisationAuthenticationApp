package com.pawana.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.pawana.entity.Exchange;
@Service
public interface Repository extends JpaRepository<Exchange,Long> {
public Exchange findBySourceAndDestination(String source,String destination);
}
